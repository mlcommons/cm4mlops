| Model    | Scenario   |   Accuracy |   Throughput | Latency (in ms)   |
|----------|------------|------------|--------------|-------------------|
| resnet50 | offline    |         76 |       17.749 | -                 |